#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <Arduino.h>
#include <stdio.h>
#include <HCSR04.h>
#include <SoftwareSerial.h>
#include <Servo.h>
#include <MFRC522.h>

//Definition des pin moteurs
#define enA 12    
#define in1 31
#define in2 30
#define enB 13
#define in3 29
#define in4 28
//definition Pin buzzer et Servomoteur
#define servo 3
#define buzz 25

//flag rfid
int check_rfid = 0;

#define RST_PIN 0         // pin RFID
#define SS_PIN 4         // pin   RFID

//pin led

#define LedVerte 11 //ledRFID    
#define Ledbleu 10 //ledcommunication
#define Ledjaune 21 //led mode auto
#define Ledrouge 24 //led mode manu
#define ledmoteurA 22
#define ledmoteurB 23

// declaration des differentes variables
String Oled ="";
int Valeur_x;
int Valeur_y;
int bouton;
int SvaleurX;
int SvaleurY;
int Switch;
int seuil_dist =30;                         //distance max que le robot peut avoir avec l'obstacle
int distance ;                              //distance donnée par le sonnar
char tram[50];

int Vit_a = 0;
int Vit_b = 0;

// definition des parametre de l'oled

#define nombreDePixelsEnLargeur 128         // Taille de l'écran OLED, en pixel, au niveau de sa largeur
#define nombreDePixelsEnHauteur 64          // Taille de l'écran OLED, en pixel, au niveau de sa hauteur
#define brocheResetOLED         -1          // Reset de l'OLED partagé avec l'Arduino (d'où la valeur à -1, et non un numéro de pin)
#define adresseI2CecranOLED     0x3C        // Adresse de "mon" écran OLED sur le bus i2c (généralement égal à 0x3C ou 0x3D)

//definition des differents modules de notre robot

SoftwareSerial BTSerial(2, 1); 
UltraSonicDistanceSensor distanceSensor(20, 15); 
Adafruit_SSD1306 ecranOLED(nombreDePixelsEnLargeur, nombreDePixelsEnHauteur, &Wire, brocheResetOLED);
Servo myservo;                              // create servo object to control a servo
byte tailleDeCaractere=1;
MFRC522 mfrc522(SS_PIN, RST_PIN);           // crée notre instance du rfid
byte nuidPICC[4];
byte NotreBadge[4] = {0x6C,0x62,0xEF,0x37}; // code de notre badge

void setup() {

  //Initialisation de la communication Serial
  Serial.begin(9600);
  BTSerial.begin(9600);

  // Initialisation de l'écran OLED
  if(!ecranOLED.begin(SSD1306_SWITCHCAPVCC, adresseI2CecranOLED))
    while(1);                                                 // Arrêt du programme (boucle infinie) si échec d'initialisation
    ecranOLED.clearDisplay();                                   // Effaçage de l'intégralité du buffer
    ecranOLED.setTextSize(tailleDeCaractere);                   // Taille des caractères (1:1, puis 2:1, puis 3:1)
    ecranOLED.setCursor(0, 0);                                  // Déplacement du curseur en position (0,0), c'est à dire dans l'angle supérieur gauche
    ecranOLED.setTextColor(SSD1306_WHITE, SSD1306_BLACK);       // Couleur du texte, et couleur du fond 

  //Definition des pins en OUTPUT pour les LED 
  pinMode(LedVerte,OUTPUT);
  pinMode(Ledbleu,OUTPUT);
  pinMode(Ledjaune,OUTPUT);
  pinMode(Ledrouge,OUTPUT);

  //Initialisation du RFID
  SPI.begin();
  mfrc522.PCD_Init();       

  // Definition des pin du moteur en sortie
  pinMode(enA, OUTPUT);
  pinMode(enB, OUTPUT);
  pinMode(in1, OUTPUT);
  pinMode(in2, OUTPUT);
  pinMode(in3, OUTPUT);
  pinMode(in4, OUTPUT);

  // Definition 

  myservo.attach(servo);
}

void enregistrer_check_rfid(){
// Enregistrer l'ID du badge (4 octets) 
  for (byte i = 0; i < 4; i++) {
    nuidPICC[i] = mfrc522.uid.uidByte[i];
  }
  
  for (byte i = 0; i < 4; i++)  {                             //on vérifie si le code correspond à celui de notre badge

    if (!nuidPICC[i] == NotreBadge[i] ){
      break;
    }
    if (i == 3 && nuidPICC[i] == NotreBadge[i]){ 
      digitalWrite(LedVerte,HIGH);                       //allumer la LED du badge
      check_rfid = 1;    
      delay(3500);
      digitalWrite(LedVerte,LOW);                        //on l'éteind après
    }  
  }
}

//Code de reception de la communication Serie
void reception(){
  if(BTSerial.available()) {
    //Reception de notre trame et tri de celle ci dans nos differentes variables
    Oled = BTSerial.readStringUntil('/');
    Valeur_x = Oled.toInt();
    Oled = BTSerial.readStringUntil('/');
    Valeur_y = Oled.toInt();
    Oled = BTSerial.readStringUntil('/');
    bouton = Oled.toInt();
    Oled = BTSerial.readStringUntil('/');
    SvaleurX= Oled.toInt();
    Oled = BTSerial.readStringUntil('/');
    SvaleurY= Oled.toInt();
    Oled = BTSerial.readStringUntil('>');
    Switch= Oled.toInt();
    //Allumer LED communication
    digitalWrite(Ledbleu, HIGH);
    delay(10);
  }
  else{
    //Eteindre LED communication
    digitalWrite(Ledbleu, LOW);
  }
}

void envoi(){
   //Ecriture de la communication
   sprintf(tram,"%d;",distance);
   BTSerial.write(tram);
}

void deplacement(){
  //Partie gestion des vitesses de deplacement en mode manuel

  if(Valeur_y<470){
    // Moteur A Avant
    digitalWrite(in1, HIGH);
    digitalWrite(in2, LOW);
    // Moteur B avant
    digitalWrite(in3, HIGH);
    digitalWrite(in4, LOW);

   if (Valeur_x<470){

     Vit_a = map(Valeur_y, 470, 0, 0, 127);
     Vit_b = map((Valeur_x + Valeur_y )/2, 470, 0, 0, 254);
     }

   else if (Valeur_x>550){

     Vit_a = map(Valeur_x - Valeur_y ,80,1023,0,254);
     Vit_b = map(Valeur_y, 470, 0, 0, 127); 
     }

   else{

     Vit_a = map(Valeur_y, 470, 0, 0, 127);
     Vit_b = map(Valeur_y, 470, 0, 0, 127);
     }

  }

 else if (Valeur_y>550){

   // Moteur A Arriere
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
    // Moteur B Arriere
    digitalWrite(in3, LOW);
    digitalWrite(in4, HIGH);

   if (Valeur_x<470){

     Vit_a = map(Valeur_y, 550, 1023, 0, 127);
     Vit_b = map(Valeur_y - Valeur_x ,80,1023,0,254);
    }

   else if (Valeur_x>550){

     Vit_a = map((Valeur_y + Valeur_x)/2, 550, 1023, 0, 254);
     Vit_b = map(Valeur_y, 550, 1023, 0, 127);  
    }

   else{

     Vit_a = map(Valeur_y, 550, 1023, 0, 127);
     Vit_b = map(Valeur_y, 550, 1023, 0, 127);
    }
 }

 else{

   if (Valeur_x<470){
     // Moteur A Arriere
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
    // Moteur B avant
    digitalWrite(in3, HIGH);
    digitalWrite(in4, LOW);

   Vit_a = map(Valeur_x, 550, 1023, 0, 127);
   Vit_b = map(Valeur_x, 550, 1023, 0, 127);

   }

   else if (Valeur_x>550){
    // Moteur A Avant
    digitalWrite(in1, HIGH);
    digitalWrite(in2, LOW);
    // Moteur B Arriere
    digitalWrite(in3, LOW);
    digitalWrite(in4, HIGH); 
    Vit_a = map(Valeur_x, 550, 1023, 0, 127);
    Vit_b = map(Valeur_x, 550, 1023, 0, 127);
    }

   else{
     Vit_a=0;
     Vit_b=0;
     }
 }

 analogWrite(enA, Vit_a); // le signal PWM A au moteur a 
 analogWrite(enB, Vit_b); // le signal PWM B au moteur b
}

void affichage(){

  //Affichage des informations sur le OLED
  ecranOLED.display();                            // Transfert le buffer à l'écran
  delay(10);
  ecranOLED.clearDisplay();
 
  ecranOLED.setCursor(0, 20);                                 
  ecranOLED.print("X1 : ");
  ecranOLED.print(String(Valeur_x));
 
  ecranOLED.setCursor(63,20);
  ecranOLED.print("| Y1 : ");
  ecranOLED.print(String(Valeur_y));
 
  ecranOLED.setCursor(0, 40);                                 
  ecranOLED.print("Angle Capteur : ");
  ecranOLED.print(String(map(SvaleurX,0,1023,0,180)));
 
  ecranOLED.setCursor(0,0);
  ecranOLED.print("Mode = ");

  if (Switch ==1){
    ecranOLED.print("Manuel");
    }
  if (Switch ==0){
    ecranOLED.print("Automatique");
    }

  ecranOLED.setCursor(0,60);
  ecranOLED.print("Distance (cm) : ");
  ecranOLED.print(String(distance));
}

void avancer(){               //fonction pour avancer

    // Moteur A Avant
    digitalWrite(in1, HIGH);
    digitalWrite(in2, LOW);
    // Moteur B avant
    digitalWrite(in3, HIGH);
    digitalWrite(in4, LOW);

    digitalWrite(ledmoteurA, HIGH);
    digitalWrite(ledmoteurB, HIGH);
    analogWrite(enA, 150);   // le signal PWM A au moteur a 
    analogWrite(enB, 150);   // le signal PWM B au moteur b
    delay(2000);
    analogWrite(enA, 0);     // le signal PWM A au moteur a 
    analogWrite(enB, 0);     // le signal PWM B au moteur b
    digitalWrite(ledmoteurA, LOW);
    digitalWrite(ledmoteurB, LOW);

}

void reculer(){              //fonction pour reculer

   // Moteur A Arriere
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
    // Moteur B Arriere
    digitalWrite(in3, LOW);
    digitalWrite(in4, HIGH);

    analogWrite(enA, 150);    // le signal PWM A au moteur a 
    analogWrite(enB, 150);    // le signal PWM B au moteur b
    delay(2000);
    analogWrite(enA, 0);      // le signal PWM A au moteur a 
    analogWrite(enB, 0);      // le signal PWM B au moteur b

}

void Turn_gauche(){           //fonction pour tourner a gauche de 90°
    // Moteur A Arriere
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
    // Moteur B avant
    digitalWrite(in3, HIGH);
    digitalWrite(in4, LOW);

    digitalWrite(ledmoteurA, HIGH); 

    analogWrite(enA, 150);   // le signal PWM A au moteur a 
    analogWrite(enB, 150);   // le signal PWM B au moteur b
    delay(2000);
    analogWrite(enA, 0);     // le signal PWM A au moteur a 
    analogWrite(enB, 0);     // le signal PWM B au moteur b

    digitalWrite(ledmoteurA, LOW);
}

void Turn_droite(){          //fonction pour tourner à droite de 90°

    // Moteur A Avant
    digitalWrite(in1, HIGH);
    digitalWrite(in2, LOW);
    // Moteur B Arriere
    digitalWrite(in3, LOW);
    digitalWrite(in4, HIGH);

    digitalWrite(ledmoteurB, HIGH); 

    analogWrite(enA, 150);    // le signal PWM A au moteur a 
    analogWrite(enB, 150);    // le signal PWM B au moteur b
    delay(2000);
    analogWrite(enA, 0);      // le signal PWM A au moteur a 
    analogWrite(enB, 0);      // le signal PWM B au moteur b

    digitalWrite(ledmoteurB, LOW);

}

void check_distance(){        //fonction pour chercker la distance avec le capteur
  analogWrite(servo, 90);  
  distance = distanceSensor.measureDistanceCm();
  delay(200);
  analogWrite(servo, 90); 
}

void check_distance_gauche(){  //fonction pour vérifier distance avec sonnar a gauche

  analogWrite(servo, 0);  
  distance = distanceSensor.measureDistanceCm();
  delay(200);
  analogWrite(servo, 90); 
}

void check_distance_droite(){   //fonction pour vérifier la distance avec sonnar à droite

  analogWrite(servo, 180);      // le signal PWM A au moteur a 
  distance = distanceSensor.measureDistanceCm();
  delay(200);
  analogWrite(servo, 90); 
}

void buzzer(){                //fonction pour allumer le buzzer quand obstacle proche detecter

  tone (buzz, 600);           // allume le buzzer actif arduino
  delay(600);
  noTone(buzz);               // désactiver le buzzer actif arduino

}

void loop() {
   
 reception();
 affichage();
 check_distance();
 envoi();

 if(bouton==1){
    //Mode Manuel
   //Actualisation des LEDS
    digitalWrite(Ledjaune, HIGH);
    digitalWrite(Ledrouge, LOW);
    digitalWrite(LedVerte, LOW);
    deplacement();
    //Controle du Servomoteur
    myservo.write(map(SvaleurX, 0, 1023, 0, 180));
    //Gestion du buzzer
    if (distance < seuil_dist && distance !=-1){
      buzzer();
    }
 }

  if(bouton==0){
    //Mode Automatique
    digitalWrite(Ledrouge, HIGH);
    digitalWrite(Ledjaune, LOW);
    // Initialisé la boucle si aucun badge n'est présent 
    if ( !mfrc522.PICC_IsNewCardPresent())
     return;

  // Vérifier la présence d'un nouveau badge 
    if ( !mfrc522.PICC_ReadCardSerial() && check_rfid !=0 )
      return;
    
    if (check_rfid !=0){       //si on a pas check avec le bon badge une fois  alors le robot fonctionne pas
      check_distance();
      if (seuil_dist <= distance) {     //si le seuil est plus petit que la distance entre robot et obstacle
        avancer();
      }
      else {                            //si on a un objet trop proche, on revérifie d'abord 
        check_distance();
        if(seuil_dist >= distance){
          check_distance_gauche();
        }
        if (seuil_dist < distance){      //si pas d'obstacle à gauche
          Turn_gauche();                 //on tourne les roues vers la gauches
        }
        if(seuil_dist >= distance){       //si tjrs pas bon , on check a droite
          check_distance_droite();   
        }
        if (seuil_dist < distance){      //si c'est bon alors on tourne a droite
          Turn_droite();                          
        }
        else {
         reculer();
        }
      }
    } 
    else{
      enregistrer_check_rfid();
    } 
  } 
}