#include <Adafruit_SSD1306.h>
#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>

#define nbrpixl 128  // largeur en pixel de oled
#define nbrpixh 64   // hauteur en pixel de oled
#define rstoled         -1   // reset oled 
#define adresseI2CecranOLED     0x3C  //adresse oled sur i2C
 
Adafruit_SSD1306 ecranOLED(nbrpixl, nbrpixh, &Wire, rstoled);
 

byte tailleDeCaractere=1;

const int Vry = 24, Vrx = 25, SW =  14, SERVy = 28, SERVx = 27;
const int BSER = 29, MANU_BOUT = 15, BUZZER = 13;
const int LED_ON =23, LED_MANU = 21, LED_AUTO = 22, LED_LT = 20;
int valbutt, man_x, man_y, ValSX, ValSY,man, distance;
String tram_rec;
char tram[40], JOY1[40],JOY2[40],DIST[40];
SoftwareSerial BTSerial(2, 1);

void setup() {
  Serial.begin(9600);
  BTSerial.begin(9600);
  pinMode(SW, INPUT);
  pinMode(MANU_BOUT, INPUT);
  pinMode(LED_ON,OUTPUT);
  pinMode(LED_MANU,OUTPUT);
  pinMode(LED_AUTO,OUTPUT);
  pinMode(LED_LT,OUTPUT);
  pinMode(BUZZER,OUTPUT);
  pinMode(SW,INPUT_PULLUP);
  digitalWrite(SW, HIGH); 
  digitalWrite(LED_ON,HIGH);
  // Initialisation de l'écran OLED
  if(!ecranOLED.begin(SSD1306_SWITCHCAPVCC, adresseI2CecranOLED))
    while(1);  // arret programe si echec initialisation
      ecranOLED.clearDisplay();// Effaçage de l'intégralité du buffer
      ecranOLED.setTextSize(tailleDeCaractere); // taille caractere
      ecranOLED.setCursor(0, 0);  // curseur en 0,0
      ecranOLED.setTextColor(SSD1306_WHITE, SSD1306_BLACK);  
                            // Couleur du texte, et couleur du fond
}

void reception(){     //fonction pour la reception
tram_rec = BTSerial.readStringUntil(';');   //prendre la distance recue
distance = tram_rec.toInt();
sprintf(DIST,"distance : %d cm ", distance);

}

void envoi(){      //fonction envoi au robot
sprintf(tram , "%d/%d/%d/%d/%d/%d>" , man_x , man_y,valbutt,ValSX,ValSY,man);         //tram qu'on envoi
BTSerial.write(tram);
delay(200);
  
}

void data_envoi(){              //fonction prise de donnée a envoyé
man_x = analogRead(Vrx);
man_y = analogRead(Vry);
ValSX = analogRead(SERVx);
ValSY = analogRead(SERVy);
valbutt = !digitalRead(SW);
man = digitalRead(MANU_BOUT);

}

void buzzer1(int rapp_cyclique){     //fonction pour allumer buzzer
analogWrite(BUZZER,rapp_cyclique);
}

void affichage(){                   //fonction d'affichage sur l'OLED

ecranOLED.setCursor(0,20);  
ecranOLED.print("Mode = ");
if (man ==1){
  ecranOLED.print("MANU");   //afficher le mode manu sur l'oled
  digitalWrite(LED_MANU,HIGH); //allumer led manu
  digitalWrite(LED_AUTO,LOW); //eteindre led auto
}
else{
  ecranOLED.print("AUTO"); //afficher le mode auto sur l'oled
  digitalWrite(LED_MANU,LOW); //eteindre led manu 
  digitalWrite(LED_AUTO,HIGH); //allumer led auto
}

ecranOLED.setCursor(0,30);//distance robot obstacle
ecranOLED.print(DIST);
ecranOLED.display();
}

void loop() {
   
data_envoi();

if(BTSerial.available()){ //lors de la connexion
  digitalWrite(LED_LT,HIGH);//allume led lt
  reception();           //on prend la trame recue
}
  else{
    digitalWrite(LED_LT,LOW); //led eteinte quand pas co
  }

envoi();
affichage();  

if (distance <= 30 && distance > 20){ //si objet trop proche
  buzzer1(80);    //on active le buzzer
}
  else if(distance<=20 && distance > 10){
    buzzer1(110);  
  }
  else if (distance <= 10 && distance > 0){
    buzzer1(130);
  }    
ecranOLED.clearDisplay();
}
